import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { UserloginService } from 'src/app/userlogin.service';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {

  constructor(private router: Router, private user:UserloginService) { }

  ngOnInit() {
  }

  loginUser(e){
    e.preventDefault();
    var username = e.target.elements[0].value;
    var password = e.target.elements[1].value;
    // console.log(username, password);
    // return false;
    if(username == 'Sumit' && password == 'Sumit@123'){
    this.user.setUserLoggedIn();
    this.router.navigate(['homepage'])
    }
    else{
      alert("Username and Password not matched.");
    }
  }
}
