import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { RouterModule, Routes } from '@angular/router';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { UserloginService } from './userlogin.service';
import { AuthGuard } from 'src/app/auth.guard';


const appRoutes: Routes=[

  {
    path: '',
    component:LoginpageComponent
  },
  {
    path: 'homepage',
    canActivate:[AuthGuard],
    component:HomepageComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    LoginpageComponent
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule
  ],
  providers: [UserloginService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
